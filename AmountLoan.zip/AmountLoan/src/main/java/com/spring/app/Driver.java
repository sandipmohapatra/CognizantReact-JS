package com.spring.app;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Driver {

    // Loads ApplicationConfig and fetches Account from the context
    public static Account loadAccount() {
        try (AnnotationConfigApplicationContext ctx =
                     new AnnotationConfigApplicationContext(ApplicationConfig.class)) {
            return ctx.getBean(Account.class);
        }
    }

    public static void main(String[] args) {
        Account account = loadAccount();

        System.out.println("Account number:" + account.getAccNumber());
        System.out.println("Account holder name:" + account.getAccHolderName());
        System.out.println("Balance:" + account.getAccBalance());
        System.out.println("Loan type:" + account.getLoanInfo().getLoanType());
        System.out.println("Loan amount:" + account.getLoanInfo().getLoanAmount());
    }
}
