
package com.spring.app;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ApplicationConfig {

    /**
     * Account is a Spring bean.
     * Loan is created inside this method (inner-bean semantics) and NOT exposed to the container.
     */
    @Bean
    public Account account() {
        return new Account(
                "335647852",   // accNumber
                "Vanitha",     // accHolderName
                250000.0,      // accBalance
                loan()         // inner object, not a Spring bean
        );
    }

    /**
     * Helper factory for the inner Loan object.
     * No @Bean annotation — NOT registered in the context.
     */
    Loan loan() {
        return new Loan("HomeLoan", 150000.0);
    }
}
