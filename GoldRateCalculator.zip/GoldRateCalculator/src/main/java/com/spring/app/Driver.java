package com.spring.app;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import java.util.Scanner;
public class Driver {

    // Fetch the GoldRateInfo bean
    public static GoldRateInfo loadGoldRateDetails()
    {
        AnnotationConfigApplicationContext ctx =
                     new AnnotationConfigApplicationContext(ApplicationConfig.class);
        {
                       return ctx.getBean(GoldRateInfo.class);
        }
    }

    public static void main(String[] args) {
        GoldRateInfo goldRateInfo = loadGoldRateDetails();

        try (Scanner sc = new Scanner(System.in)) {
            System.out.println("Enter the carat:");
            int carat = Integer.parseInt(sc.nextLine().trim());

            System.out.println("Enter Total Grams:");
            double grams = Double.parseDouble(sc.nextLine().trim());

            double total = goldRateInfo.calculateGoldRate(carat, grams);
            System.out.println("Total Gold Rate is Rs:" + total);
        }
    }
}
