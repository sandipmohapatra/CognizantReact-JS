package com.spring.app;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import java.util.Map;
@Component
public class GoldRateInfo {

    private Map<Integer, Double> rateInfo;

    public Map<Integer, Double> getRateInfo() {
        return rateInfo;
    }

   
    @Value("#{${gold.rate.map}}")
    public void setRateInfo(Map<Integer, Double> rateInfo) {
        this.rateInfo = rateInfo;
    }

   
    public double calculateGoldRate(int goldCarat, double grams) 
    {
        if (rateInfo == null || rateInfo.isEmpty()) {
            throw new IllegalStateException("Gold rate information is not configured.");
        }
        Double perGramRate = rateInfo.get(goldCarat);
        if (perGramRate == null) {
            throw new IllegalArgumentException("No rate configured for carat: " + goldCarat);
        }
        return perGramRate * grams;
    }
}
