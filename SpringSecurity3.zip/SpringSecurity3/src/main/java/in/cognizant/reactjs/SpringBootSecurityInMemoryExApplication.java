package in.cognizant.reactjs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootSecurityInMemoryExApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootSecurityInMemoryExApplication.class, args);
	}

}
